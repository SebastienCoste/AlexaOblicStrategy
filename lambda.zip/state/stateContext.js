var stateContext = Object.freeze({
  states: {
    IDENTIFICATION: '',
    QUESTIONNING: '_QUESTIONNING',
    BETWEEN_QUESTIONS: '_BETWEEN_QUESTIONS'

  }
})

module.exports = stateContext;
