'use strict';

const Alexa = require('alexa-sdk');
const interaction = require('../helpers/interaction');

const stateContext = require('./stateContext');

const questionningHandler = Alexa.CreateStateHandler(stateContext.states.QUESTIONNING, {

  'RepeatIntent': function() {
    interaction.repeatQuestion(this);
  },
  'AnswerIntent': function() {
    interaction.treatAnswer(this);
  },
  'StartIntent': function() {
    interaction.startContest(this);
  },

  'AMAZON.HelpIntent': function() {
    interaction.helpQuestionning(this);
  },
  'AMAZON.CancelIntent': function() {
    interaction.cancel(this);
  },
  'AMAZON.StopIntent': function() {
    interaction.stopIt(this);
  },
  'StopIntent': function() {
    interaction.stopIt(this);
  },
  'SessionEndedRequest': function() {
    interaction.stopIt(this);
  },
  'Unhandled': function() {
    interaction.unhandled(this);
  }
});

module.exports = questionningHandler;
